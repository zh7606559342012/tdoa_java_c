#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "tdoa.h"

#define BS_NUM (8)

int main(int argc, char **argv)
{
    double dt_temp[BS_NUM]      = {0, -118.6343/1e9, -130.2083/1e9, -117.1875/1e9, 0, 11.5741/1e9, 128.7616/1e9, 10.1273/1e9};
    double seq_xyz[BS_NUM][3]   = {{0,0,0}, {0,10,0}, {20,10,0}, {20,0,0}, {10,0,0}, {10,10,0}, {30,10,0}, {30,0,0}};

    tdoa_pos_t  *p_ms           = new tdoa_pos_t;
    tdoa_pos_t  *p_bs_vec       = new tdoa_pos_t[BS_NUM];
    tdoa_time_t *p_time_vec     = new tdoa_time_t[BS_NUM];

    for (uint16_t ii = 0; ii < BS_NUM; ii++)
    {
        memcpy(p_bs_vec[ii].xyz, seq_xyz[ii], sizeof(seq_xyz[0]));
    }

    memcpy(p_time_vec, dt_temp, BS_NUM * sizeof(dt_temp[0]));

    VelPos::tdoa_calc_1(p_bs_vec, p_time_vec, 8, p_ms);

    printf("(x, y, z) = (%f, %f, %f)\n", p_ms->x, p_ms->y, p_ms->z);

    delete p_ms;
    delete p_bs_vec;
    delete p_time_vec;

    return 0;
}